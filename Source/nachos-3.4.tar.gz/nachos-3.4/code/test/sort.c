/* sort.c 
 *    Test program to sort a large number of integers.
 *
 *    Intention is to stress virtual memory system.
 *
 *    Ideally, we could read the unsorted array off of the file system,
 *	and store the result back to the file system!
 */

#include "syscall.h"

int main()
{
	int a[100];
	int i,j,n, key;
	PrintString("Nhap so phan tu n: ");
	n = ReadInt();
	if (n>100)
	{
	    return;	
    	}	
	for (i=0;i<n;i++)
	{
		PrintString("Nhap phan tu thu ");
		PrintInt(i+1);
		PrintString(": ");
		a[i]=ReadInt();		
	}
	PrintString("nhap 1 de sap xep tang dan \n");
	PrintString("nhap 2 de sap xep giam dan \n");
	key = ReadInt();
	for (i=0;i<n-1;i++){
		for(j=i+1;j<n;j++){
			if (key==1)			
			{
				if (a[i]>a[j])	
				{
					int tg=a[i];
					a[i]=a[j];
					a[j]=tg;
				}
			}
			else
			{
				if (a[i]<a[j])	
				{
					int tg=a[i];
					a[i]=a[j];
					a[j]=tg;
				}
			}
		}
	}
	PrintString("==> Sau khi sap xep : ");
	for (i=0;i<n;i++)
	{	
		PrintInt(a[i]);
		PrintChar(' ');
	}
	Halt();	
}
