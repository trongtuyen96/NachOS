#include "syscall.h"
#include "copyright.h"

int main()
{
	int re;
	re=ReadInt();
	PrintInt(re);
	Halt();
}
