#include "syscall.h"
#include "copyright.h"
#define maxlen 255

int 
main()
{
 
   
// int openfile;
 //openfile = Open("stdout",0);
// if(openfile == -1) return;
 if(Write("",5,1)==-1)
	return;
 
    /*print("\nCreate file~");
    print(filename);
    print(" success~");
    */
   
  Halt();
}
