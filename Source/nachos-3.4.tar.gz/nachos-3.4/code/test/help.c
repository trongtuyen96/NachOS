#include "syscall.h"
#include "copyright.h"

int main()
{
	PrintString("Nhom: \n");
	PrintString(" * Nguyen Trong Tuyen - 1453057\n");
	PrintString(" * Nguyen Viet Thuong - 1453048\n");
	PrintString(" * Nguyen Tien Phuc   - 1453033\n");
	PrintString(" * Le Thanh Tuan      - 1453066\n");
	PrintString("\n");
	PrintString(" ==> ASCII: cho bien chay lan luot tu 0->255 va in ra dung ham PrintChar in ra ki tu tuong ung");
	PrintString("\n");
	PrintString(" ==> SORT: \n");
	PrintString("  Nhap 1 de sap xep tang dan \n");
	PrintString("    cho i chay tu 0 ->n \n");
 	PrintString("    neu a[i] > a[i+1] thi swap\n");
	PrintString("  Nhap 2 de sap xep giam dan \n");
	PrintString("    cho i chay tu 0 ->n \n");
	PrintString("    neu a[i] < a[i+1] thi swap\n");
	Halt();
}
