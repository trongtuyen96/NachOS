#include "syscall.h"
#include "copyright.h"

int main()
{
	PrintInt(2000000000);
	Halt();
}
