#include "syscall.h"
#include "copyright.h"

int main()
{
	char st[200];
	ReadString(st,200);
	PrintString(st);
	Halt();
}
