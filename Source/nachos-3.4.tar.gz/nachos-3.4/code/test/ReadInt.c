#include "syscall.h"
#include "copyright.h"

int main()
{
	int num;
	num=ReadInt();
	Halt();
}
