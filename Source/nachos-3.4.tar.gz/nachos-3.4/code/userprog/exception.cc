// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#define MAX 2000
#define MAXL 200
//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

//Input: - User space address (int)
//	-Limit of buffer (int)
//Output:- Buffer (char*)
//Purpose: Copy buffer from User memory space to System 
//memory space

char* User2System(int virtAddr, int limit)
{
 int i;//index
 int oneChar;
 char* kernelBuf=NULL;
 kernelBuf = new char[limit+1];//need for terminal string
 if(kernelBuf == NULL)
    return kernelBuf;
 memset(kernelBuf,0,limit+1);
 //printf("\n Filename u2s:");
 for(i=0;i<limit;i++)
 {
   machine->ReadMem(virtAddr+i,1,&oneChar);
   kernelBuf[i] = (char)oneChar;
   //printf("%c",kernelBuf[i]);
   if(oneChar == 0)
	break;
 }
 return kernelBuf;
}

//Input: -User space address (int)
//       -Limit of buffer (int)
//       -Buffer (char[])
//Output:-Number of bytes copied (int)
//Purpose: Copy buffer from System memory space to User
// memory space

int System2User(int virtAddr, int len, char*buffer)
{
  if(len<0) return -1;
  if(len == 0) return len;
  int i=0;
  int oneChar = 0;
  do{
      oneChar= (int) buffer[i];
      machine->WriteMem(virtAddr+i,1,oneChar);
      i++;
  }while(i<len && oneChar!=0);
 return i;
}

void ProgramCounter() // Increase Program Counter from machine
{
	int i;
	machine->WriteRegister(PrevPCReg,machine->ReadRegister(PCReg));
	i=machine->ReadRegister(NextPCReg);
	machine->WriteRegister(PCReg,i);
	i+=4;
	machine->WriteRegister(NextPCReg,i);
}

void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);
    switch(which)
	{
        case NoException:
	    printf("No Exception");
			ProgramCounter();
		break;
		case PageFaultException:
			printf("PageFaultException");
			ProgramCounter();
		break;
		case ReadOnlyException:
		printf("ReadOnlyException");
			ProgramCounter();
		break;
		case BusErrorException:
		printf("BusErrorException");
			ProgramCounter();
		break;
		case AddressErrorException:
		printf("AddressErrorException");
			ProgramCounter();
		break;
		case OverflowException:
		printf("OverflowException");
			ProgramCounter();
		break;
		case IllegalInstrException:
		printf("IllegalInstrException");
			ProgramCounter();
		break;
		case NumExceptionTypes:
		printf("NumExceptionTypes");
			ProgramCounter();
		break;
		case SyscallException:
			switch(type)
			{
				case SC_Halt:
			    {
		            DEBUG('a',"\n Shutdown, initiated by user progarm.");
					printf("\n\n Shutdown, initiated by user program.");
					interrupt->Halt();
					break;
				}
				case SC_Sub:
				{ // Substract 2 numbers
					int op1 = machine->ReadRegister(4);
					int op2 = machine->ReadRegister(5);
					int result = op1 - op2;
					machine->WriteRegister(2,result);
					interrupt->Halt();
					break;
				}

				case SC_ReadInt:
				{
					char *buffer=new char[11];
					int res=0, i=0;
					int Check;
					Check=gSynchConsole->Read(buffer,11);
					// Kiem tra du lieu
					if(Check>11)
					{	
						res=0;
						break;
					}
					else
					{
						res=0;i=0;
						if(buffer[0]=='-')
						{
							i=1;
						}
						for(;i<Check;i++)
						{
							if(buffer[i]<48 || buffer[i]>57)
							{
								res=0;
								break;
							}
							res=res*10+(int)(buffer[i]-48);
						}
						if(buffer[0]=='-')
						{
							res=-res;
						}
					}
				
					//Gioi Han Cua Int
					//if(res<-2147483648 || res>2147483647)
					//{
						//res=0;
					//}
					
					machine->WriteRegister(2,res);
					ProgramCounter();
					delete buffer;
					break;
				}

				case SC_ReadChar:
				{
					char *s =new char[2]; 
					int check;
					check = gSynchConsole->Read(s,1); //doc 1 phan tu gan vao s
					// Kiem tra du lieu
					if(check==-1)
					{
						break;
					}
					else
					{
						machine->WriteRegister(2,(int)s[0]); 
					}
					delete s;
					ProgramCounter();
					break;
				}

				case SC_PrintInt:  
				{
					int res = machine->ReadRegister(4);
					char *buffer = new char[sizeof(int)];
					sprintf(buffer,"%d",res);//casting gia tri tu res sang buffer
					gSynchConsole->Write(buffer,strlen(buffer));
					delete buffer;
					ProgramCounter();
					break;
				}

				case SC_PrintChar:
				{
					int res=machine->ReadRegister(4); //lay gia tri tu thanh ghi
					char *buffer=new char[4]; // do char co size =1 va int co size =4 nen phai tao mang char[4] de casting
					buffer[0]=(char) res; //casting tu res sang buffer
					gSynchConsole->Write(buffer,1);
					ProgramCounter();
					delete buffer;
					break;
				}
				case SC_ReadString:
				{
					int Addr=machine->ReadRegister(4);
					int Length=machine->ReadRegister(5);
					char *buffer=new char[MAX];
					int n;
					while(1)
					{
						n=gSynchConsole->Read(buffer,MAX);
						if(n>Length)
						{
							gSynchConsole->Write(" Too Long..",27);
							n=Length;
							break;
						}
						break;
					}
					System2User(Addr,n,buffer);
					delete buffer;
					ProgramCounter();
					break;
				}
				case SC_PrintString:
				{
					int Length;
					int res=machine->ReadRegister(4);
					char *buffer=new char[MAX];
					buffer=User2System(res,MAX+1); //lay dia chi tu page table
					if(buffer==NULL)
						break;
					Length=1;
					while(buffer[Length]!='\0')//dem so luong ki tu trong string
					{
						Length++;
					}
					gSynchConsole->Write(buffer,Length);
					ProgramCounter();
					delete buffer;
					break;
				}
				case SC_Create:
				{
					int virtAddr;
					char* filename;
					printf("\n SC_Create call...");
					printf("\n Reading virtual address of filename");
					virtAddr = machine->ReadRegister(4);
					printf("\n Reading filename");
					filename = User2System(virtAddr,MAX+1);
					if(filename == NULL)
					{
						printf("\n Not enough memory in system");
						machine->WriteRegister(2,-1);
						delete filename;
						return;
					}
					printf("\n Finish reading filename.");
					if(!fileSystem->Create(filename,0))
					{
						printf("\n Error create file '%s'",filename);
						machine->WriteRegister(2,-1);
						delete filename;
						return;
					}
					machine->WriteRegister(2,0);
					delete filename;
					break;
				}
				case SC_Open:
				{
					// kiem tra id co thoa yeu cau (0<=id<=9 )
					if(fileSystem->fileIndex > 9)
					{
						printf("ID khong thoa dieu kien 0<=ID<=9 \n");
						machine->WriteRegister(2,-1);
						return;
					}
					//neu id thoa yeu cau
					int virtAddr,fileType; 
					char* fileName;
					// doc ten file
					printf("Doc ten file...\n");
					virtAddr = machine->ReadRegister(4); 
					// doc loai file
					printf("Doc loai file...\n");
					fileType = machine->ReadRegister(5);
					
					// kiem tra loai file co bang 1 hoac 0
					
					
					if(fileType != 1 && fileType != 0 )
					{
						printf("Khong xac dinh duoc loai file \n");
						machine->WriteRegister(2,-1);
						return;
					}
					
					
					
					// chuyen file name sang kernel mode
					fileName = User2System(virtAddr, MAXL);
					// kiem tra file co phai la Console input
					
					if (strcmp(fileName, "stdin") == 0)
					{
						printf("Mo file Console input \n");
						machine->WriteRegister(2, 0);
						delete fileName;
						break;
					}
					// kiem tra file co phai la Console output
					if (strcmp(fileName, "stdout") == 0)
					{
						printf("Mo file Console output \n");
						machine->WriteRegister(2, 1);
						delete fileName;
						break;
					}
					
					// kiem tra file co ton tai hay khong
					fileSystem->fileList[fileSystem->fileIndex] = fileSystem->Open(fileName,fileType);
					if (fileSystem->fileList[fileSystem->fileIndex] == NULL)
					{
						printf("file khong ton tai, tien hanh tao file moi\n");
						fileSystem->fileList[fileSystem->fileIndex] = new OpenFile(virtAddr,fileType);
						machine->WriteRegister(2,fileSystem->fileIndex);
						break;
					}
					//neu file ton tai
					
					if (fileType == 0)
						printf("Mo file %s de doc va ghi  \n",fileName);
					else
						printf("Mo file %s de doc  \n",fileName);
					machine->WriteRegister(2, fileSystem->fileIndex);
					ProgramCounter();
					delete fileName;
					break; 
				}
				case SC_Close:
				{	
					int fileIndex = machine->ReadRegister(4);//doc tu thanh ghi thu 4
					//kiem tra file co ton tai hay khong
					if (fileSystem->fileList[fileIndex] != NULL )
					{ 
						delete fileSystem->fileList[fileIndex];//xoa khoi bang file
						fileSystem->fileList[fileIndex] = NULL;//set ve null
					}
					break;
				}
				
				case SC_Read:
				{
					int bufAddr,fileSize,fileIndex;
					bufAddr = machine->ReadRegister(4);
					fileSize = machine->ReadRegister(5);
					fileIndex = machine->ReadRegister(6);
					
					// kiem tra id co thoa yeu cau (0<=id<=9 && id!=1)
					// id = 1 --> file : Console output
					if(fileIndex > 9 || fileIndex < 0 || fileIndex ==1 )
					{
						printf("ID khong thoa yeu cau 0<=id<=9 && id!=1 \n");
						machine->WriteRegister(2,-1);
						return;
					}
					
					//kiem tra file co ton tai hay khong
					if(fileSystem->fileList[fileIndex] == NULL)
					{
						printf("File khong ton tai\n");
						machine->WriteRegister(2,-1);
						return; 
					}
					
					char *buf = new char [fileSize];
					if (!buf)
					{
						printf("khong du bo nho cap phat cho buf \n");
						machine->WriteRegister(2,-1);
						delete[] buf;
						return;
					}
					buf = User2System(bufAddr,fileSize);
					
					// id = 0 --> file : Console input
					if (fileIndex == 0)
					{
						printf("File : Console input \n");
						int length = gSynchConsole->Read(buf, fileSize);
						if (length < 0) 
						{
							printf(" Khong doc duoc \n");
							machine->WriteRegister(2,-1);
							delete[] buf; 
							return;
						}
						//them ki tu '\0' vao cuoi chuoi
						buf[length] = '\0'; 
						length++;
						System2User(bufAddr, length, buf);
						machine->WriteRegister(2,length);
						delete[] buf;
						break;
					}
					
					//------------
				}
				
				case SC_Write:
				{
					int Buffer,Charcount,Index;
					Buffer = machine->ReadRegister(4);
					Charcount = machine->ReadRegister(5);
					if(Charcount <= 0)
					{
						machine->WriteRegister(2,-1);
						printf("Kich thuoc khong phu hop\n");
						break;
					}
					Index = machine->ReadRegister(6);
					//Kiem tra ID
					if(!(Index>=0 && Index<10))
					{
						machine->WriteRegister(2,-1);
						printf("ID khong phu hop\n");
						break;
					}
					
					
					char *Message = new char [Charcount];
					//Kiem tra bo nho
					if (!Message)
					{
						machine->WriteRegister(2,-1);
						printf("Khong du bo nho cap phat cho Message \n");
						delete[] Message;
						ProgramCounter();
						break;
					}
					Message = User2System(Buffer,Charcount);
					
					
					// id = 1 --> file : Console output
					if (Index == 1)
					{
						printf("File: Console output\n");
						int i = 0;
						while (Message[i] != 0 && Message[i] != '\n')
						{
							gSynchConsole->Write(Message+i, 1);
							i++;
						}
						machine->WriteRegister(2, i);
						delete[] Message;
						ProgramCounter();
						break;
					}		
					//id = 0 --> file: Console input
					if(Index == 0)
					{
						printf("File: Console input\n");
						printf("Khong the viet tren Console input\n");
						machine->WriteRegister(2,-1);
						ProgramCounter();
						break;
					}
					//Kiem tra file co trong du lieu hay khong
					if(fileSystem->fileList[Index] == NULL)
					{
						machine->WriteRegister(2,-1);
						printf("File khong ton tai\n");
						ProgramCounter();
						break;
					}
					
					
					//Cac id con lai
					int count= fileSystem->fileList[Index]->WriteAt(Message,strlen(Message),fileSystem->fileList[Index]->GetCurrentPos());
					machine->WriteRegister(2,count);
					ProgramCounter();
					break;
					//------------
				}
				default:
					printf("\n Unexpected user mode exception (%d %d)",which,type);
					interrupt->Halt();
			}
	}       
}


